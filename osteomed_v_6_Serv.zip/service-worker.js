/* service-worker.js */

const CACHE_NAME = 'osteomed-v2';
const ASSETS_TO_CACHE = [
  '/'
  // Не добавляйте сюда '/index.html' — .htaccess редиректит этот URL на '/',
  // а Cache API не позволяет кэшировать редиректнутый response (addAll падает с ошибкой).
  // Сюда можно добавить пути к вашим CSS и JS файлам, если нужно
];

// Установка: кэшируем основные файлы
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Активация: удаляем старые кэши
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

// Перехват запросов
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});

// Слушаем команду от sw-register.js для обновления
self.addEventListener('message', (event) => {
  if (event.data && event.data.action === 'skipWaiting') {
    self.skipWaiting();
  }
});