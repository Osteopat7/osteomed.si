// sw-register.js — PRO
window.addEventListener('load', () => {
  if (!('serviceWorker' in navigator)) return;
  const swUrl = '/service-worker.js'; // строго маленькими буквами, без ?v
  navigator.serviceWorker.register(swUrl)
    .then(reg => {
      console.log('✅ SW registered:', reg.scope);
      // Периодическая проверка обновлений на сервере (каждые 30 минут)
      setInterval(() => {
        try { reg.update(); } catch (e) {}
      }, 30 * 60 * 1000);
      // Если при загрузке уже есть ожидающий воркер — активируем его
      if (reg.waiting) {
        reg.waiting.postMessage({ action: 'skipWaiting' });
      }
      // Отслеживание появления обновлений
      reg.addEventListener('updatefound', () => {
        const newWorker = reg.installing;
        console.log('🔄 SW update found');
        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed') {
            if (navigator.serviceWorker.controller) {
              // Новый контент готов — даем команду на активацию
              console.log('🔁 New SW installed — activating');
              newWorker.postMessage({ action: 'skipWaiting' });
              // Плавная перезагрузка страницы для показа новых данных
              setTimeout(() => { window.location.reload(); }, 350);
            } else {
              console.log('🎉 SW installed for first time');
            }
          }
        });
      });
    })
    .catch(err => console.error('❌ SW registration failed:', err));
}); 